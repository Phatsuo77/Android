package com.first.android.aub

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import coil3.compose.AsyncImage
import com.first.android.ClothList
import com.first.android.ClothModel

@Preview(showSystemUi = true)
@Composable
fun PreviewClothDetailScreen() {
    val nc = rememberNavController()
    ClothDetailScreen(nc, ClothList[0])
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClothDetailScreen(nc: NavController, item: ClothModel) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("Cloth Detail")
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = Color.Black,
                    navigationIconContentColor = Color.Black,
                ),
                navigationIcon = {
                    IconButton(
                        onClick = {
                            nc.popBackStack()
                        }
                    ) {
                        Icon(
                            Icons.Default.ArrowBackIosNew,
                            contentDescription = null,
                        )
                    }
                }
            )
        }
    ) {
        Box(
            modifier = Modifier.padding(it)
        ) {
            ClothDetailScreenBody(item, nc)
        }
    }
}

@Composable
fun ClothDetailScreenBody(item: ClothModel, nc: NavController) {
    return Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(350.dp),
                shape = RoundedCornerShape(
                    topStart = 10.dp,
                    topEnd = 10.dp
                ),
                color = Color.Gray,
                border = BorderStroke(
                    width = 1.dp,
                    color = Color(0xFFDBE0DB)
                ),
            ) {
                AsyncImage(
                    model = item.img,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                )
            }
            Surface(
                modifier = Modifier
                    .fillMaxWidth(),
                shape = RoundedCornerShape(
                    bottomStart = 10.dp,
                    bottomEnd = 10.dp
                ),
                border = BorderStroke(
                    width = 1.dp,
                    color = Color(0xFFDBE0DB)
                )
            ) {
                Column(
                    modifier = Modifier.padding(10.dp)
                ) {
                    Text(
                        item.title,
                        style = TextStyle(fontSize = 25.sp),
                    )
                    Text(
                        "USD ${item.price}",
                        style = TextStyle(fontSize = 18.sp),
                    )
                }
            }
            Text("SIZE", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 23.sp)
            //Size Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(onClick = {}) {
                    Text("S", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Button(onClick = {}) {
                    Text("M", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Button(onClick = {}) {
                    Text("L", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(15.dp))
            Text("QUANTITY", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 23.sp)
            //Quantity Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Button(onClick = {}) {
                    Text("-", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Button(onClick = {}) {
                    Text("1", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Button(onClick = {}) {
                    Text("+", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {},
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("ADD TO BAG", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }