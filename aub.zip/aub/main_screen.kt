package com.first.android.aub

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import coil3.compose.AsyncImage
import com.first.android.ClothList

@Preview(showSystemUi = true)
@Composable
fun PreviewClothScreen() {
    val nc = rememberNavController()
    Cloth(nc)
}

@Composable
fun Cloth(nc: NavController){
    Scaffold (
        topBar = {
            ClothTopAppBar(nc)
        },
        bottomBar = {
            ClothBottomAppBar(nc)
        },
    ){
        Box(
            modifier = Modifier.padding(it)
        ){
            ClothScreenBody(nc)
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClothTopAppBar(nc: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Ten11",
                        fontWeight = FontWeight.Bold,
                        style = TextStyle(fontSize = 30.sp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = Color.Black,
                ),
                actions = {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Notifications, contentDescription = null)

                    }
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.ShoppingBag, contentDescription = null)
                    }
                    IconButton(onClick = {nc.navigate("aboutus_screen")}) {
                        Icon(Icons.Default.Settings, contentDescription = null)
                    }
                }
            )
        }
    ) {
        Box(
            modifier = Modifier.padding(it)
        ) {
            ClothScreenBody(nc)
        }
    }
}
@Composable
fun ClothBottomAppBar(nc: NavController){
    BottomAppBar (
        actions = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ){
                IconButton(
                    onClick = {}
                ) { Icon(Icons.Default.Home, contentDescription = "Home") }
                IconButton(
                    onClick = {}
                ) { Icon(Icons.Default.Menu, contentDescription = "Menu") }
                IconButton(
                    onClick = {}
                ) { Icon(Icons.Default.QrCode, contentDescription = "QR") }
                IconButton(
                    onClick = {nc.navigate("search_screen")}
                ) { Icon(Icons.Default.Search, contentDescription = "Search") }
                IconButton(
                    onClick = {}
                ) { Icon(Icons.Default.Person, contentDescription = "Person") }
            }
        }
    )
}
@Composable
fun ClothScreenBody(nc: NavController) {
    LazyColumn() {
        items(ClothList.size) {
            Column(
                modifier = Modifier.padding(10.dp),
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                        .clickable{
                            nc.navigate("detail_screen/${ClothList[it].id}")
                        }
                        ,
                    shape = RoundedCornerShape(
                        topStart = 10.dp,
                        topEnd = 10.dp
                    ),
                    color = Color.Gray,
                    border = BorderStroke(
                        width = 1.dp,
                        color = Color(0xFFDBE0DB)
                    ),
                ) {
                    AsyncImage(
                        model = ClothList[it].img,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                    )
                }
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(
                        bottomStart = 10.dp,
                        bottomEnd = 10.dp
                    ),
                    border = BorderStroke(
                        width = 1.dp,
                        color = Color(0xFFDBE0DB)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp)
                    ) {
                        Text(
                            ClothList[it].title,
                            style = TextStyle(fontSize = 25.sp),
                        )
                        Text(
                            "USD ${ClothList[it].price}",
                            style = TextStyle(fontSize = 18.sp),
                        )
                        }
                    }
                }
            }
        }
    }