package com.first.android.aub

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import coil3.compose.AsyncImage

@Preview(showSystemUi = true)
@Composable
fun Loginform(){
    val nc = rememberNavController()
    Loginform(nc)
}
@Composable
fun Loginform(nc: NavController) {
    var tel by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var hide by remember { mutableStateOf(true) }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(900.dp),
        shape = RoundedCornerShape(40.dp),
        color = Color.White,

        ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().height(600.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                TextField(
                    modifier = Modifier.padding(10.dp).width(400.dp),
                    value = tel,
                    onValueChange = { tel = it },
                    shape = RoundedCornerShape(
                        size = 100.dp,
                    ),
                    placeholder = { Text("Mobile Number") },
                    leadingIcon = {
                        Icon(Icons.Default.Phone, contentDescription = null)
                    },
                    textStyle = TextStyle(
                        color = Color.Black,
                    ),
                    colors = TextFieldDefaults.colors(
                        unfocusedContainerColor = Color.LightGray,
                        focusedContainerColor = Color.White,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                    )
                )
                TextField(
                    modifier = Modifier.padding(10.dp).width(400.dp),
                    value = password,
                    onValueChange = { password = it },
                    shape = RoundedCornerShape(
                        size = 100.dp,
                    ),
                    placeholder = { Text("Password") },
                    leadingIcon = {
                        Icon(Icons.Default.Key, contentDescription = null)
                    },
                    textStyle = TextStyle(
                        color = Color.Black,
                    ),
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                hide = !hide
                            }
                        ) {
                            Icon(
                                if (hide) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = null
                            )
                        }
                    },
                    colors = TextFieldDefaults.colors(
                        unfocusedContainerColor = Color.LightGray,
                        focusedContainerColor = Color.White,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                    ),
                    visualTransformation =
                    if (hide) PasswordVisualTransformation()
                    else VisualTransformation.None,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                    )
                )
                Box(
                    modifier = Modifier.padding(20.dp).width(300.dp),
                    contentAlignment = Alignment.Center,
                ){
                    Button(onClick = {
                        if (tel == "070216852" && password == "1234") {
                            nc.navigate("main_screen")
                            result = "Login Successfully";
                        } else {
                            result = "Login Failed";
                        }
                    }, modifier = Modifier.fillMaxWidth().width(200.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBCF8DD))
                        )
                    {
                        Text("LOGIN", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                }
                //Forgot Password
                Text("Forgot Your Password?", color = Color.Gray, fontSize = 16.sp)

                Spacer(modifier = Modifier.height(10.dp))
                Text("OR", color = Color.Black, fontSize = 16.sp)

                Spacer(modifier = Modifier.height(15.dp))
                //Social Login
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    IconButton(onClick = { /* Google Login */ }) {
                        AsyncImage(
                            model = "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Google_%22G%22_logo.svg/2048px-Google_%22G%22_logo.svg.png",
                            contentDescription = "Google Login",
                            modifier = Modifier.size(50.dp).clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))
                    IconButton(onClick = { /* Facebook Login */ }) {
                        AsyncImage(
                            model = "https://cdn-icons-png.flaticon.com/128/5968/5968764.png",
                            contentDescription = "Facebook Login",
                            modifier = Modifier.size(50.dp),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    IconButton(onClick = { /* Instagram Login */ }) {
                        AsyncImage(
                            model = "https://cdn-icons-png.flaticon.com/128/174/174855.png",
                            contentDescription = "Instagram Login",
                            modifier = Modifier.size(50.dp),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
                //Register
                Spacer(modifier = Modifier.height(17.dp))
                Text(
                    "New in Ten11? / Register", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 16.sp
                )
                Text("$result")
            }
        }
    }
}