package com.first.android.aub

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.PhoneIphone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import coil3.compose.AsyncImage


@Preview(showSystemUi = true)
@Composable
fun Aboutus(){
    val nc = rememberNavController()
    Aboutus(nc)
}
@Composable
fun Aboutus (nc: NavController) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(900.dp),
        shape = RoundedCornerShape(40.dp),
        color = Color.White
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().height(600.dp).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "TEN11 App",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Spacer(modifier = Modifier.height(15.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Spacer(modifier = Modifier.height(15.dp))
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.PhoneIphone, contentDescription = null)
                    }
                    Text("Android App")
                }
                Row (
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Spacer(modifier = Modifier.height(15.dp))
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.PhoneIphone, contentDescription = null)
                    }
                    Text("IOS App")
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    "FOLLOW US",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Spacer(modifier = Modifier.height(15.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    IconButton(onClick = { /* Facebook */ }) {
                        AsyncImage(
                            model = "https://cdn-icons-png.flaticon.com/128/2175/2175193.png",
                            contentDescription = "Facebook",
                            modifier = Modifier.size(50.dp).clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    IconButton(onClick = { /* Instagram */ }) {
                        AsyncImage(
                            model = "https://cdn-icons-png.flaticon.com/128/2111/2111491.png",
                            contentDescription = "Instagram",
                            modifier = Modifier.size(50.dp).clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    IconButton(onClick = { /* Tik Tok */ }) {
                        AsyncImage(
                            model = "https://cdn-icons-png.flaticon.com/128/3046/3046120.png",
                            contentDescription = "Tik Tok",
                            modifier = Modifier.size(50.dp).clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    IconButton(onClick = { /* Telegram */ }) {
                        AsyncImage(
                            model = "https://cdn-icons-png.flaticon.com/128/2582/2582606.png",
                            contentDescription = "Telegram",
                            modifier = Modifier.size(50.dp).clip(RoundedCornerShape(10.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally // Ensures everything is centered
                ) {
                    Text(
                        "CUSTOMER SERVICE",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Spacer(modifier = Modifier.height(15.dp))
                        IconButton(onClick = {}) {
                            Icon(Icons.Default.Help, "Online Exchange Policy")
                        }
                        Text("Online Exchange Policy")
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Spacer(modifier = Modifier.height(10.dp))
                        IconButton(onClick = {}) {
                            Icon(Icons.Default.Security, "Online Exchange Policy")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Privacy policy")
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Spacer(modifier = Modifier.height(10.dp))
                        IconButton(onClick = {}) {
                            Icon(Icons.Default.ChatBubble, contentDescription = null)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("FAQs and guide")
                    }
                }
            }
        }
    }
}