package com.first.android.aub

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController

@Preview(showSystemUi = true)
@Composable
fun Searchscreen(){
    val nc = rememberNavController()
    search(nc)
}

@Composable
fun search(nc: NavController){
    Scaffold (
        topBar = {
            SearchTopAppBar(nc)
        },
        bottomBar = {
            SearchBottomAppBar(nc)
        },
    ){
        Box(
            modifier = Modifier.padding(it)
        ){
            Searchscreen(nc)
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchTopAppBar(nc: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "",
                        fontWeight = FontWeight.Bold,
                        style = TextStyle(fontSize = 30.sp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = Color.Black,
                ), navigationIcon = {
                    IconButton(onClick = {nc.popBackStack()}) {
                        Icon(
                            Icons.Default.ArrowBackIosNew,
                            contentDescription = null,
                        )
                    }
                },
                actions = {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Notifications, contentDescription = null)

                    }
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.ShoppingBag, contentDescription = null)
                    }
                    IconButton(onClick = {nc.navigate("aboutus_screen")}) {
                        Icon(Icons.Default.Settings, contentDescription = null)

                    }
                }
            )
        }
    ) {
        Box(
            modifier = Modifier.padding(it)
        ) {
            Searchscreen(nc)
        }
    }
}
@Composable
fun SearchBottomAppBar(nc: NavController){
    BottomAppBar (
        actions = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ){
                IconButton(
                    onClick = {}
                ) { Icon(Icons.Default.Home, contentDescription = "Home") }
                IconButton(
                    onClick = {}
                ) { Icon(Icons.Default.Menu, contentDescription = "Menu") }
                IconButton(
                    onClick = {}
                ) { Icon(Icons.Default.QrCode, contentDescription = "QR") }
                IconButton(
                    onClick = {nc.navigate("search_screen")}
                ) { Icon(Icons.Default.Search, contentDescription = "Search") }
                IconButton(
                    onClick = {}
                ) { Icon(Icons.Default.Person, contentDescription = "Person") }
            }
        }
    )
}


@Composable
fun Searchscreen(nc: NavController){
    var search by remember { mutableStateOf("") }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(900.dp),
        shape = RoundedCornerShape(40.dp),
        color = Color.White,

        ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().height(900.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                TextField(
                    modifier = Modifier.padding(10.dp).width(400.dp),
                    value = search,
                    onValueChange = { search = it },
                    shape = RoundedCornerShape(
                        size = 100.dp,
                    ),
                    placeholder = { Text("Search") },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null)
                    },
                    textStyle = TextStyle(
                        color = Color.Black,
                    ),
                    colors = TextFieldDefaults.colors(
                        unfocusedContainerColor = Color.LightGray,
                        focusedContainerColor = Color.White,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                    )
                )
            }
        }
    }
}