package com.first.android.aub

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.first.android.ClothList

@Preview(showSystemUi = true)
@Composable
fun Ten11App() {
    val nc = rememberNavController()

    NavHost(
        navController = nc,
        startDestination = "login_screen"
    ) {
        composable("login_screen") {
            Loginform(nc)
        }
        composable("main_screen") {
            Cloth(nc)
        }
        composable(
            "detail_screen/{id}",
            arguments = listOf(navArgument("id") {
                type = NavType.IntType
            })
        ) { backStackEntry ->
            val id = backStackEntry.arguments?.getInt("id")
            val selectedItem = ClothList.firstOrNull { it.id == id }
            selectedItem?.let {
                ClothDetailScreen(nc, it)
            }
        }
        composable("search_screen"){
            search(nc)
        }
        composable("aboutus_screen"){
            Aboutus(nc)
        }
    }
}
