package com.first.android


data class ClothModel(
    var id: Int = 0,
    var title: String= "no title",
    var img: String= "no img",
    var price: Double= 0.00,

    )
var ClothList: List<ClothModel> = listOf(
    ClothModel(
        id = 1,
        title = "Crop Top",
        img = "https://zandokh.com/image/cache/catalog/products/2025-02/22224111143%20Out-door/DSC01667%20copy-cr-450x672.jpg",
        price = 3.89,
    ),
    ClothModel(
        id = 2,
        title = "Mini Dresses",
        img = "https://zandokh.com/image/cache/catalog/products/2025-01/22224111059/Ten112434-cr-450x672.jpg",
        price = 17.50,
    ),
    ClothModel(
        id = 3,
        title = "Regular Polo Shirt",
        img = "https://zandokh.com/image/cache/catalog/products/2025-02/2122409766%20out%20door/8J6A0519-cr-450x672.jpg",
        price = 19.59,
    ),
    ClothModel(
        id = 4,
        title = "Knitted Polo Shirts",
        img = "https://zandokh.com/image/cache/catalog/products/2025-02/2112410002%20out-door/8J6A0460-cr-450x672.jpg",
        price = 22.59,
    ),
)